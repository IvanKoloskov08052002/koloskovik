<header class="header">
            <div class="header-logo">
                <a class="bottons" href="/">ГрумRoom</a>
                <img src="3" alt="" srcset="" class="header-img">
            </div>
            <div class="header-content">
                <a href="index.php">Главная</a>
                <a href="#">Админ панель</a>
                <a href="#">Личный кабинет</a>
            </div> 
            <div class="header-botton">
            <a class="bottons" href="/atoruzonion.php" >Вход</a>
            <a class="bottons" href="reg/reg.php">Регистрация</a>
            </div>
</header>
